#ifndef FLUSHRELOAD_H
#define FLUSHRELOAD_H

#include "args.h"

#define MAX_PROBES 32

void startSpying(args_t *args);

#endif
